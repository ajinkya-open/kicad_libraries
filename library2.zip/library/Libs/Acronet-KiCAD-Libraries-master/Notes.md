# NOTES #
---------

As of February 2015 the *.mod* format library (*ACRONET.mod*) is no longer updated; all the modules were converted in the new *.kicad_mod* format and collected in the **acronet.pretty** folder.  
