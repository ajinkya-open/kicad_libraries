Acronet-KiCAD-Libraries
=======================

This folder contains *.lib*, *.dcm*, *.mod* and *.kicad_mod* [files](http://kicad-pcb.org/help/file-formats/) to design [AcroBoards](http://www.acronet.cc) using [KiCad EDA Software Suite](http://www.kicad-pcb.org/display/KICAD/KiCad+EDA+Software+Suite).

# LICENSE #

*All of the files in this folder are licensed under a [Creative Commons Attribution-ShareAlike 4.0 Unported License](http://creativecommons.org/licenses/by-sa/4.0/) and the [Open Source Hardware (OSHW) Definition 1.0](http://freedomdefined.org/OSHW).*

[![alt][2]][1] [![alt][4]][3]

[1]: http://creativecommons.org/licenses/by-sa/4.0/
[2]: http://i.creativecommons.org/l/by-sa/4.0/88x31.png (Creative Commons Attribution-ShareAlike 4.0 Unported License.)

[3]: http://freedomdefined.org/OSHW
[4]: http://www.oshwa.org/wp-content/uploads/2014/03/oshw-logo-antipixel.png



----------


# Disclaimer #

THE CONTENT OF THIS FOLDER IS PROVIDED "AS IS" AND "WITH ALL FAULTS". ACRONET&reg; DISCLAIMS ALL OTHER WARRANTIES, EXPRESS OR IMPLIED, REGARDING PRODUCTS, INCLUDING BUT NOT LIMITED TO, ANY IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
